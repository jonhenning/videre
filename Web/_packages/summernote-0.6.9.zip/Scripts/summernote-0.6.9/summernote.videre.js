﻿
$(document).ready(function()
{
    if (window.videre == null)
        alert('videre.js is missing');

    videre.UI.registerControlType('summernote', {
        get: function(ctl)
        {
            return ctl.code();
        },
        set: function(ctl, val)
        {
            if (val != null)
                val = val.replace(new RegExp('\\[\\[\\[BASEURL\\]\\]\\]', 'g'), videre.resolveUrl('~/'));
            ctl.code(val);
        },
        init: function(ctr)
        {
            var fontNames = ['Open Sans'];//$('body').css('font-family').split(',');
            fontNames.addRange($.summernote.options.fontNames);
            ctr.find('[data-controltype=\"summernote\"]').summernote({ fontNames: fontNames, height: '350px' });    //todo: hardcode height???
        }
    });
});