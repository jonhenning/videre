
$(document).ready(function()
{
    var docs = $('.videre-docs-content');   //html container must have the videre-docs-content specified in css
    var sidebarPane = $('.pane-sidebar');   //assume we are using a layout that has the pane-sidebar class defined
    if (docs.length > 0 && sidebarPane.length > 0)
    {
        var sidebar = $('<div></div>').addClass('videre-docs-sidebar');
        var body = $('body');
        var bodyPadding = parseInt(body.css('padding-top'));

        createSideMenuFromContent(docs, null, sidebar, 1, 'videre-docs-sidenav', 'help', bodyPadding);
        sidebarPane.append(sidebar);
        sidebar.affix({ offset: { top: sidebarPane.offset().top } });
        body.scrollspy({ target: '.videre-docs-sidebar', offset: bodyPadding });
    }

    function createSideMenuFromContent(container, prev, parent, level, css, parentId, bodyPadding)
    {
        if (level > 5)  //only scan 5 levels
            return;

        var h = prev != null ? prev.nextUntil('h' + (level - 1), 'h' + level) : container.find('h' + level);
        if (h.length == 0)  //if none at this level, look a level deeper
            createSideMenuFromContent(container, prev, parent, level + 1, css, parentId, bodyPadding);
        if (h.length > 0)
        {
            var ul = $('<ul></ul>').addClass('nav ').addClass(css).appendTo(parent);
            $.each(h, function(idx, item)
            {
                item = $(item);
                var id = safeId(item.text(), parentId);
                item.attr('id', id).css({ 'padding-top': bodyPadding + 'px', 'margin-top': '-' + bodyPadding + 'px' });   //hack to allow fixed menu - http://stackoverflow.com/questions/7420434/jquery-how-to-get-elements-margin-and-padding
                var a = $('<a></a>').text(item.text()).attr('href', '#' + id);
                var li = $('<li></li>').appendTo(ul);
                a.appendTo(li);
                createSideMenuFromContent(container, item, li, level + 1, null, id, bodyPadding);
            });
        }
    }

    function safeId(id, parentId)
    {
        var id = id.replace(/[ \.]/g, '-').replace(/[\r\n\t\_\(\)\/\,\']/g, '').toLowerCase();
        return parentId + '-' + id;
    }
});

