videre.UI.registerControlType('bootstrap-datetimepicker', {
    get: function(ctl)
    {
        var d = ctl.data('DateTimePicker').getDate();
        if (d != null)
        {
            if (ctl.data('timezone') != null)
            {
                var zone = videre.timeZones.getOffset(ctl.data('timezone'), d).Format;
                if (zone.indexOf('-') != 0 && zone.indexOf('+') != 0)
                    zone = '+' + zone;
                d = moment(d.format('YYYY-MM-DDTHH:mm:ss') + zone).zone(zone); //by default it uses browser zone.. so grab string without zone, append zone to string for parse via moment(), then reassign zone
            }

            if (ctl.data('datatype') == 'date')
                return moment.utc(d.local().format('YYYY-MM-DD')).toISOString();
            else if (ctl.data('datatype') == 'time')
                return moment.utc(d).format(videre.localization.dateFormats.time);
        }
        return d;
    },
    set: function(ctl, val)
    {
        if (String.isNullOrEmpty(val))
        {
            ctl.val('');
            ctl.data('DateTimePicker').setDate(null);
        }
        else
        {
            var d = videre.parseDate(val, null, ctl.data('timezone'));
            ctl.data('DateTimePicker').setDate(d);
        }
    },
    init: function(ctr)
    {
        $.each(ctr.find('[data-controltype="bootstrap-datetimepicker"]'), function()
        {
            var ctl = $(this);
            var dataType = ctl.data('datatype') != null ? ctl.data('datatype') : '';
            var options = { pickDate: dataType.indexOf('date') > -1, pickTime: dataType.indexOf('time') > -1 };
            if (videre.localization.dateFormats[dataType] != null)
                options.format = videre.localization.dateFormats[dataType];

            ctl.datetimepicker(options);
            ctl.data('DateTimePicker').setDate(null); 	//init to null so no default chosen
            ctl.change(function(e)
            {
                var d = ctl.data('DateTimePicker').getDate();
                if (d != null && d.isValid() && d.year() < 1970)
                    ctl.data('DateTimePicker').setDate(d.add(2000, 'y'));
            });

        });
    }
});