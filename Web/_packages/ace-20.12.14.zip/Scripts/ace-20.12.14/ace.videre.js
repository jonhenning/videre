﻿
$(document).ready(function()
{
    if (window.videre == null)
        alert('videre.js is missing');

    videre.UI.registerControlType('ace', {
        get: function(ctl)
        {
            return ctl.val();
        },
        set: function(ctl, val)
        {
            ctl.val(val);
            var div = $('#' + ctl.attr('data-editor'));
            var editor = ace.edit(div.attr('id'));
            var session = editor.getSession();

            //need to ensure its visible!
            if (div.is(':hidden'))
            {
                var parent = div.parent();
                var tempDiv = $('<div></div>');
                div.replaceWith(tempDiv);
                div.appendTo($(document.body));
                session.setValue(val, -1);
                editor.renderer.updateFull(true);
                editor.resize();
                tempDiv.replaceWith(div);
            }
            else
                session.setValue(val, -1);
        },
        init: function(ctr)
        {
            var ctls = ctr.find('[data-controltype=\"ace\"]');

            $('<style> .ace-fullscreen { position: fixed; width: 100%; height: 100%!important; top: 0; left: 0; right: 0; bottom: 0; z-index: 9999; }</style>').appendTo($('head'));

            ctls.each(function(idx, ctl)
            {
                ctl = $(ctl).hide();
                var id = ctl.attr('id');
                if (id == null)
                {
                    id = '_aceeditor_' + idx;
                    ctl.attr({ id: 'ta' + id, 'data-editor': id });
                }
                var div = $('<div></div>').appendTo(ctl.parent()).attr('id', id).addClass('col-md-12').css('height', '300px');

                var editor = ace.edit(id);
                editor.setTheme("ace/theme/twilight");
                var session = editor.getSession();
                session.setMode("ace/mode/html");
                session.on('change', function(e)
                {
                    ctl.val(editor.getValue());
                    ctl.trigger('change');
                });

                editor.commands.addCommand({
                    name: 'Fullscreen',
                    bindKey: 'Ctrl-F11',
                    exec: function(editor)
                    {
                        if (div.css('position') == 'fixed')
                        {
                            var tempDiv = $('#' + div.attr('id') + '_fs');
                            tempDiv.replaceWith(div);
                            div.removeClass('ace-fullscreen');
                        }
                        else
                        {
                            var parent = div.parent();
                            var tempDiv = $('<div></div>').attr('id', div.attr('id') + '_fs');
                            div.replaceWith(tempDiv);
                            div.prependTo($(document.body));
                            div.addClass('ace-fullscreen');
                        }
                        editor.resize();
                        editor.focus();
                    }
                });
                editor.commands.addCommand({
                    name: 'Fullscreen esc',
                    bindKey: 'esc',
                    exec: function(editor)
                    {
                        if (div.css('position') == 'fixed')
                        {
                            var tempDiv = $('#' + div.attr('id') + '_fs');
                            tempDiv.replaceWith(div);
                            div.removeClass('ace-fullscreen');
                            editor.resize();
                            editor.focus();
                        }
                    }
                });

            });
        }
    });
});