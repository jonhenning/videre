﻿
$(document).ready(function()
{
    if (window.videre == null)
        alert('videre.js is missing');

    videre.UI.registerControlType('cktexteditor4', {
        get: function(ctl)
        {
            return ctl.val();
        },
        set: function(ctl, val)
        {
            if (val != null)
                val = val.replace(new RegExp('\\[\\[\\[BASEURL\\]\\]\\]', 'g'), videre.resolveUrl('~/'));
            ctl.val(val);
        },
        init: function(ctr)
        {
            CKEDITOR.basePath = videre.resolveUrl('~/scripts/ckeditor-4.4.7/');
            CKEDITOR.plugins.basePath = videre.resolveUrl('~/scripts/ckeditor-4.4.7/plugins/');

            ctr.find('[data-controltype=\"cktexteditor4\"]').ckeditor(function(textarea)
            {
                $(textarea).on('blur', function(e)
                {
                    if (e.editor.checkDirty())
                    {
                        e.editor.updateElement();
                        $(e.editor.element.$).trigger('change');
                    }
                })
            },
            {
                allowedContent: true,
                filebrowserBrowseUrl: videre.resolveUrl('~/Admin/FileBrowser?MimeType=image'),
                contentsCss: $('link').toArray().where(function(d) { return d.href.indexOf('layout.css') == -1; }).toList(function(d) { return d.href; })//,
                //toolbarGroups: [
                //    { name: 'clipboard', groups: ['clipboard', 'undo'] },
                //    { name: 'editing', groups: ['find', 'selection', 'spellchecker'] },
                //    { name: 'links' },
                //    { name: 'insert' },
                //    { name: 'forms' },
                //    { name: 'tools' },
                //    { name: 'document', groups: ['mode', 'document', 'doctools'] },
                //    { name: 'others' },
                //    '/',
                //    { name: 'basicstyles', groups: ['basicstyles', 'cleanup'] },
                //    { name: 'paragraph', groups: ['list', 'indent', 'blocks', 'align'] },
                //    { name: 'styles' },
                //    { name: 'colors' },
                //    { name: 'about' }
                //]
            });
        }
    });
});