﻿if (window.videre == null)
    alert('videre.js is missing');

videre.UI.registerControlType('bootstrap-select', {
    get: function(ctl) { return ctl.val() != null ? ctl.val() : ''; },
    set: function(ctl, val)
    {
        val = (val != null ? val : '');
        if (videre.typename(val) != 'array')
            val = val.toString();
        ctl.val(val);
        ctl.selectpicker('refresh');
    },
    init: function(ctr) { ctr.find('[data-controltype=\"bootstrap-select\"]').selectpicker(); }
});

videre.UI.registerControlType('claims-list',
{
    get: function(ctl)
    {
        var val = ctl.val() != null ? ctl.val() : [];
        return val.select(function(v)
        {
            var parts = v.split(':');
            return { Issuer: parts[0], Type: parts[1], Value: parts.slice(2, parts.length).join('') };
        });
    },
    set: function(ctl, val)
    {
        var selected = [];
        if (val != null)
        {
            val.forEach(function(data)
            {
                var name = String.format('{0}:{1}:{2}', data.Issuer, data.Type, data.Value);
                if (ctl.find('option[value="' + name + '"]').length == 0)
                    ctl.append($('<option></option>').val(name).html(name));
                selected.push(name);
            });
        }

        ctl.val(selected);
        ctl.selectpicker('refresh');
    },

    init: function(ctl)
    {
        if ($('').selectpicker != null)
        {
            var list = ctl.find('[data-controltype="claims-list"]');
            
            list.each(function(idx, ctl)
            {
                var options = {};
                ctl = $(ctl);
                if (ctl.css('width') != null)
                    options.width = ctl.css('width');
                ctl.selectpicker(options);
            });
            
            list.parent().find('[data-action="addclaim"]').click(function(e)
            {
                videre.UI.prompt(videre.UI.getNextId(), 'Add Claim', '', [{ label: 'Issuer', dataColumn: 'Issuer' }, { label: 'Type', dataColumn: 'Type' }, { label: 'Value', dataColumn: 'Value' }],
                    [{
                        text: 'Ok', css: 'btn-primary', close: true, handler: function(data)
                        {
                            var select = $(e.target).closest('.input-group').find('select');
                            if (!String.isNullOrEmpty(data.Issuer) && !String.isNullOrEmpty(data.Type) && !String.isNullOrEmpty(data.Value))
                            {
                                var name = String.format('{0}:{1}:{2}', data.Issuer, data.Type, data.Value);
                                select.append($('<option selected="selected"></option>').val(name).html(name));
                                select.selectpicker('refresh');
                                return true;
                            }
                        }
                    }, { text: 'Cancel', css: 'btn-default', close: true }]);

            });
        }
        else
            setTimeout(function() { videre.UI._controlTypes['claims-list'].init(ctl); }, 100);
    }
});
