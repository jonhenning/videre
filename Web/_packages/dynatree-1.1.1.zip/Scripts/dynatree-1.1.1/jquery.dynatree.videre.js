if (window.videre == null)
    alert('videre.js is missing');

videre.tree = {
    getTreeData: function (rootName, data, func, delim)
    {
        delim = (delim == null) ? '/' : delim;
        var root = { title: rootName, isFolder: true, key: '', children: [] };
        var lookup = {};
        lookup[''] = root;
        for (var row = 0; row < data.length; row++)
        {
            var key = func(data[row]); //[column];
            var path = '';
            var parts = key.split(delim);
            for (var i = 0; i < parts.length; i++)
            {
                var parent = lookup[path];
                path += (path.length ? delim : '') + parts[i];
                if (lookup[path] == null)
                {
                    lookup[path] = { title: parts[i], isFolder: i < parts.length - 1, key: path, children: [] };
                    parent.children.push(lookup[path]);
                    parent.children = parent.children.orderBy(function(d) { return d.title; });
                }
            }
        }
        return root;
    }
};
